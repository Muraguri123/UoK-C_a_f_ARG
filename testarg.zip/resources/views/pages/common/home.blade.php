@extends('layouts.unauthorizedtemplate')

@section('content')
   <div class="jumbotron text-center">
      <h3>U.O.K Call for Papers </h3>
   </div>
@endsection