

<?php $__env->startSection('content'); ?>
<div class="row">
    <h1><?php echo e($proposal->title); ?></h1>
    <p><?php echo e($proposal->description); ?></p>

    <div>
        <h2>Made by</h2>
        <p><?php echo e($proposal->applicant->name); ?></p>
    </div>

    <div>
        <h2>Created at</h2>
        <p><?php echo e($proposal->created_at->format('F j, Y')); ?></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/proposals/viewproposal.blade.php ENDPATH**/ ?>