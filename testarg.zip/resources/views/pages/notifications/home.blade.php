@extends('layouts.master')

@section('content')
<div class="row">

    @auth
        <div>
            <h5>Notifications Coming Soon</h5>
        </div>
    @endauth
</div>
@endsection