

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
   <div class="row justify-content-center ">
      <div class=" col-4 text-center" style="padding-right:0px">
         <?php if(auth()->guard()->check()): ?> 
          <div class="card">
            <div class="card-header">
               <h5>Warning Message</h5>
            </div>
            <div class="card-body text-danger">
               <?php if(isset($message)): ?>
               <b><?php echo e($message); ?></b>
            <?php endif; ?>
            </div>

          </div>
       <?php endif; ?>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/unauthorized.blade.php ENDPATH**/ ?>