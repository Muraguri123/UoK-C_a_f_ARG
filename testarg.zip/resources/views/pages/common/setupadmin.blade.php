@extends('layouts.unauthorizedtemplate')

@section('content')
<div class="row text-center">
   <h5>
      You have successfully logged in but as an initializing account.
   </h5> <br />
   <p>Kindly log in as an administrator to continue</p>
</div>
@endsection