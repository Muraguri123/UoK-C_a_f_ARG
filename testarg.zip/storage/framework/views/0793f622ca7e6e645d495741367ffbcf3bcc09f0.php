
<?php $__env->startSection('content'); ?>
   i am the contact page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/contact.blade.php ENDPATH**/ ?>