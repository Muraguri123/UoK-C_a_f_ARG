<!-- <footer class="footer navbar-light" style="background-color: lightblue;">
  <div class="container-fluid justify-content-center text-dark ">
    <b>UNIVERSITY OF KABIANGA - </b>Created by <a href="https://Tagile.com">Tagile Solutions</a> &middot; &copy;
    {{ date('Y') }}
  </div>
</footer> -->


<footer class="footer navbar-light" style="background-color: lightblue;">
    <div class="container d-flex justify-content-center ">
        <div class="text-dark text-center mainfooter-text">
            UNIVERSITY OF KABIANGA - Created by <a href="https://Tagile.com" class="text-dark">Tagile Solutions</a> &middot; &copy; {{ date('Y') }}
        </div>
    </div>
</footer>
