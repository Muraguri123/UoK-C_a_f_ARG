
    $(document).ready(function() {
        $('#menuToggle').click(function() {
            alert('Button was clicked!');
        });
    });