

<?php $__env->startSection('content'); ?>
<div>
    <style>
        .prop-tabcontainer {
            background-color: #FAF9F6;
            border-radius: 4px;
        }

        .prop-tabpanel {
            border-width: 1px;
            border-color: gray;
            background-color: #FAF9F6;
            border-style: solid;
            border-radius: 4px;
            padding: 8px;
        }
    </style>
    <?php if(auth()->guard()->check()): ?>
        <div class="prop-tabcontainer">
            <!-- Nav tabs -->
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link active" id="nav-personal-tab" data-bs-toggle="tab"
                        data-bs-target="#panel-basicdetails" type="button" role="tab" aria-controls="panel-basicdetails"
                        aria-selected="true">Basic Details</button>
                    <button class="nav-link" id="nav-research-tab" data-bs-toggle="tab" data-bs-target="#panel-research"
                        type="button" role="tab" aria-controls="panel-profile" aria-selected="false">Research</button>
                    <button class="nav-link" id="nav-collaboration-tab" data-bs-toggle="tab"
                        data-bs-target="#panel-collaboration" type="button" role="tab" aria-controls="panel-collaboration"
                        aria-selected="false">Collaboration</button>
                    <button class="nav-link" id="nav-finance-tab" data-bs-toggle="tab" data-bs-target="#panel-finance"
                        type="button" role="tab" aria-controls="panel-finance" aria-selected="false">Finance</button>
                    <button class="nav-link" id="nav-researchdesign-tab" data-bs-toggle="tab"
                        data-bs-target="#panel-researchdesign" type="button" role="tab" aria-controls="panel-researchdesign"
                        aria-selected="false">Research Design</button>
                    <button class="nav-link" id="nav-workplan-tab" data-bs-toggle="tab" data-bs-target="#panel-workplan"
                        type="button" role="tab" aria-controls="panel-workplan" aria-selected="false">Workplan</button>
                </div>
            </nav>

            <!-- Tab panes -->
            <div class="tab-content prop-tabpanel">
                <!-- basicdetails tab -->
                <div role="tabpanel" class="tab-pane active" id="panel-basicdetails">
                    <!-- Personal details form -->
                    <form method="POST" id="basicdetails" action="<?php echo e(route('route.proposals.postnewproposal')); ?>"
                        enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Full Name
                                </label></div>
                            <div class="col-12 col-md-9"><input type="text" id="fullname" placeholder="Your Full Name"
                                    disabled="" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Email
                                </label>
                            </div>
                            <div class="col-12 col-md-9"><input type="text" id="email" placeholder="Your Full Name"
                                    disabled="" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Department Name</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="department" placeholder="Department" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Highest
                                    Qualification</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="highestqualification" placeholder="Highest Qualification"
                                    class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Office
                                    Telephone</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="officephone" placeholder="Office Telephone" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Cellphone</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="cellphone" placeholder="Cellphone" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Fax Number</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="faxnumber" placeholder="Fax Number" class="form-control">
                            </div>
                        </div>


                    </form>

                    <div class="row form-group">
                        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                            <button id="startbutton" form="" type="submit" class="btn btn-primary "
                                style="width:200px; margin-top:8px;">Start</button>

                        </div>
                    </div>
                </div>

                <!-- Research tab -->
                <div role="tabpanel" class="tab-pane" id="panel-research">
                    <form id="form_researchinfo" method="POST" action="<?php echo e(route('route.proposals.postnewproposal')); ?>"
                        enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Research Title
                                </label></div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="researchtitle" placeholder="Research Title" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">
                                    Research Theme</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <select class="form-select form-select-sm" aria-label=".form-select example">
                                    <option value="" disabled selected>Select your Application Theme</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Objectives</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="objectives" placeholder="Objectives" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Question/Hypothesis</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea type="text" id="hypothesis" placeholder="Question or Hypothesis"
                                    class="form-control"></textarea>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Significance</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="significance" placeholder="Significance or Justification"
                                    class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Ethical Considerations</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="ethicals" placeholder="Ethical Considerations"
                                    class="form-control"></textarea>

                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Expected Outputs</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="outputs" placeholder="Expected Outputs" class="form-control"></textarea>

                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Socio-Economic Impact</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="economicimpact" placeholder="Socio-Economic Impact"
                                    class="form-control"></textarea>

                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Research Findings</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <textarea id="economicimpact" placeholder="Dissemination of Research Findings"
                                    class="form-control"></textarea>

                            </div>
                        </div>
                    </form>
                    <div class="row form-group">
                        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                            <button id="saveresearchinfobutton" form="form_researchinfo" type="submit"
                                class="btn btn-primary " style="width:200px; margin-top:8px;">Save All</button>

                        </div>
                    </div>
                </div>

                <!-- Collaborators tab -->
                <div role="tabpanel" class="tab-pane" id="panel-collaboration">
                    <!-- Collaborators details form -->
                     <div class="row form-group">
                        <table id="colltable" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">position</th>
                                    <th scope="col">institution</th>
                                    <th scope="col">Area</th>
                                    <th scope="col">experience</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>

                    <!--Collaborator Modal -->
                    <div class="modal fade" id="collaboratormodal" data-bs-backdrop="static" data-bs-keyboard="false"
                        tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="staticBackdropLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="form_collaborators" method="POST"
                                        action="<?php echo e(route('route.proposals.postcollaborator')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <!-- Collaborators details form fields -->
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Collaborator Name</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="collaboratorname" placeholder="Collaborator Name"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Position</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="position" placeholder="Position"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Institution</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="institution" placeholder="Institution"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Research
                                                    Area</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="researcharea" placeholder="Research Area"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Research
                                                    Experience</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="researchexperience" placeholder="Research Experience"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                                                <button id="addCollaboratorButton" type="submit" class="btn btn-success "
                                                    style="width:200px">Add</button>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Understood</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Publication Modal -->
                    <div class="modal fade" id="publicationmodal" data-bs-backdrop="static" data-bs-keyboard="false"
                        tabindex="-1" aria-labelledby="publicationLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="publicationLabel">Add New Publication</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="form_collaborators" method="POST"
                                        action="<?php echo e(route('route.proposals.postcollaborator')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <!-- Collaborators details form fields -->
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Authors (s)</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="authors" placeholder="Authors"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Year</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="year" placeholder="Year"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3">
                                                <label class=" form-control-label">Title</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="pubtitle" placeholder="Title"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Research
                                                    Area</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="researcharea" placeholder="Research Area"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Publisher</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="publisher" placeholder="Publisher"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Volume</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="volume" placeholder="Volume"
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-3"><label class=" form-control-label">Pages</label>
                                            </div>
                                            <div class="col-12 col-md-9">
                                                <input type="text" id="pubpages" placeholder="Pages"
                                                    class="form-control">
                                            </div>
                                        </div>

                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button id="addpublicationButton" type="submit" class="btn btn-success "
                                        style="width:200px">Add Publication</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row form-group">
                        <!-- Button trigger modal -->
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#collaboratormodal">Add Collaborator</button>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#publicationmodal">Add Publication</button>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-12">
                            <button id="savecollaboratorsbutton" form="form_collaborators" type="submit"
                                class="btn btn-primary " style="width:200px; margin-top:8px;">Save All</button>

                        </div>
                    </div>
                    <script>
                        document.getElementById('addCollaboratorButton').addEventListener('click', function () {
                            var tablecontainer = document.getElementById('colltable');
                            var cname = document.getElementById('collaboratorname').value;
                            var cposition = document.getElementById('position').value;
                            var cinstitution = document.getElementById('institution').value;
                            var carea = document.getElementById('researcharea').value;
                            var cexperience = document.getElementById('researchexperience').value;
                            console.log(tablecontainer.rows.length);
                            if (tablecontainer.rows.length < 6) {
                                var newCollaborator = document.createElement('tr');
                                newCollaborator.innerHTML = '<td></td><td>' + cname + '</td>' + '<td>' + cposition + '</td>' + '<td>' + cinstitution + '</td>' + '<td>' + carea + '</td>' + '<td>' + cexperience + '</td>';
                                tablecontainer.appendChild(newCollaborator);
                            } else {
                                alert('You can only add up to three collaborators.');
                            }

                        });
                    </script>
                </div>

                <!-- Finance Tab -->
                <div role="tabpanel" class="tab-pane " id="panel-finance">
                    <form id="form_finance" method="POST" action="<?php echo e(route('route.proposals.postnewproposal')); ?>"
                        enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Total Funds
                                </label></div>
                            <div class="col-12 col-md-9"><input type="text" id="totalfunds" placeholder="0.00" disabled=""
                                    value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Equipments Cost</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="number" id="equipmentscost" placeholder="0.00" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Consumables Cost</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="number" id="consumablescost" placeholder="0.00" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Travel Cost</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="number" id="travelcost" placeholder="0.00" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Other Cost</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="number" id="othercost" placeholder="0.00" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">
                                    Commencing Date</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="date" id="commencingdate" placeholder="DD/MM/YYYY" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">
                                    Termination Date</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="date" id="terminationdate" placeholder="DD/MM/YYYY" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">

                        </div>
                        <div class="row form-group">
                            <h4>Expenditure Breakdown</h4>
                        </div>
                    </form>

                    <div class="row form-group">
                        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                            <button id="savefinancebutton" form="form_finance" type="submit" class="btn btn-primary "
                                style="width:200px; margin-top:8px;">Save All</button>

                        </div>
                    </div>
                </div>
                <!-- Research Design -->
                <div role="tabpanel" class="tab-pane" id="panel-researchdesign">
                    <!-- Research design details form -->
                    <form id="form_researchdesign" method="POST" action="<?php echo e(route('route.proposals.postcollaborator')); ?>">
                        <?php echo csrf_field(); ?>
                        <!-- Collaborators details form fields -->
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Project Summary</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="projectsummary" placeholder="Project Summary" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Indicators</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="indicators" placeholder="Measurable Indicators" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Verification</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="verification" placeholder="Means of Verification"
                                    class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Assumptions</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="assumptions" placeholder="Important Assumptions"
                                    class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Goal</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="goal" placeholder="Goal" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Purpose</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="purpose" placeholder="Purpose" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                                <button id="addresearchdesignButton" type="submit" class="btn btn-success "
                                    style="width:200px">Add</button>

                            </div>
                        </div>
                    </form>
                    <div class="row form-group">
                        <h2 class="mt-5">Research Design Items</h2>

                    </div>
                    <div class="row form-group">
                        <table id="researchdesigntable" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">position</th>
                                    <th scope="col">institution</th>
                                    <th scope="col">Area</th>
                                    <th scope="col">experience</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <div class="row form-group">
                        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                            <button id="saveresearchdesignbutton" form="form_researchdesign" type="submit"
                                class="btn btn-primary " style="width:200px; margin-top:8px;">Save All</button>

                        </div>
                    </div>
                    <script>
                        document.getElementById('addCollaboratorButton').addEventListener('click', function () {
                            var tablecontainer = document.getElementById('colltable');
                            var cname = document.getElementById('collaboratorname').value;
                            var cposition = document.getElementById('position').value;
                            var cinstitution = document.getElementById('institution').value;
                            var carea = document.getElementById('researcharea').value;
                            var cexperience = document.getElementById('researchexperience').value;
                            console.log(tablecontainer.rows.length);
                            if (tablecontainer.rows.length < 6) {
                                var newCollaborator = document.createElement('tr');
                                newCollaborator.innerHTML = '<td></td><td>' + cname + '</td>' + '<td>' + cposition + '</td>' + '<td>' + cinstitution + '</td>' + '<td>' + carea + '</td>' + '<td>' + cexperience + '</td>';
                                tablecontainer.appendChild(newCollaborator);
                            } else {
                                alert('You can only add up to three collaborators.');
                            }

                        });
                    </script>
                </div>

                <!-- Workplan -->
                <div role="tabpanel" class="tab-pane" id="panel-workplan">
                    <form id="form_workplan" method="POST" action="<?php echo e(route('route.proposals.postcollaborator')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Activity</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="activity" placeholder="Activity undertaken" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Time</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="time" placeholder="Time" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class=" form-control-label">Input</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="input" placeholder="Input" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Facilities</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="facilities" placeholder="Facilities " class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">By Whom</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="bywhom" placeholder="By Whom" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3"><label class=" form-control-label">Outcome</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="outcome" placeholder="Outcome" class="form-control">
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                                <button id="addresearchdesignButton" type="submit" class="btn btn-success "
                                    style="width:200px">Add</button>

                            </div>
                        </div>
                    </form>
                    <div class="row form-group">
                        <h2 class="mt-5">Workplan Items</h2>

                    </div>
                    <div class="row form-group">
                        <table id="researchdesigntable" class="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">position</th>
                                    <th scope="col">institution</th>
                                    <th scope="col">Area</th>
                                    <th scope="col">experience</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <div class="row form-group">
                        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-4 offset-md-4">
                            <button id="saveworkplanbutton" form="form_workplan" type="submit" class="btn btn-primary "
                                style="width:200px; margin-top:8px;">Save All</button>

                        </div>
                    </div>
                    <script>
                        document.getElementById('addCollaboratorButton').addEventListener('click', function () {
                            var tablecontainer = document.getElementById('colltable');
                            var cname = document.getElementById('collaboratorname').value;
                            var cposition = document.getElementById('position').value;
                            var cinstitution = document.getElementById('institution').value;
                            var carea = document.getElementById('researcharea').value;
                            var cexperience = document.getElementById('researchexperience').value;
                            console.log(tablecontainer.rows.length);
                            if (tablecontainer.rows.length < 6) {
                                var newCollaborator = document.createElement('tr');
                                newCollaborator.innerHTML = '<td></td><td>' + cname + '</td>' + '<td>' + cposition + '</td>' + '<td>' + cinstitution + '</td>' + '<td>' + carea + '</td>' + '<td>' + cexperience + '</td>';
                                tablecontainer.appendChild(newCollaborator);
                            } else {
                                alert('You can only add up to three collaborators.');
                            }

                        });
                    </script>
                </div>

            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/proposals/newproposal.blade.php ENDPATH**/ ?>