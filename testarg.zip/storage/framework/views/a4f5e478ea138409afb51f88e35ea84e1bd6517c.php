

<?php $__env->startSection('content'); ?>
<div class="row">

    <?php if(auth()->guard()->check()): ?>
        <div>
            <h5>Notifications Coming Soon</h5>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/notifications/home.blade.php ENDPATH**/ ?>