<div id="overlay" class="overlay"></div>
<nav id="sidebar" class="sidebar sidebar-collapsed bg-light">
  <button class="close-btn" type="button" id="closeSidebar" aria-label="Close sidebar">
    <i class="bi bi-x"></i>
  </button>
  <div class="position-sticky sidebar-sticky">
    <ul class="nav flex-column">
      <li class="nav-item">
        <a class="list-group-item list-group-item-action" style="border:0px" href="<?php echo e(route('pages.dashboard')); ?>">
          <i class="bi bi-house"> </i>Dashboard
        </a>

      </li> <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="nav-item">
      <a class="nav-link  " style="border:0px" href="<?php echo e(route($menuitem->path)); ?>">
        <i class="bi bi-arrow-right-short"></i><?php echo e($menuitem->menuname); ?></a>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      <li class="nav-item ">
        <a class="nav-link " href="<?php echo e(route('pages.notifications')); ?>">
          <i class="bi bi-bell-fill"></i> Notifications </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route("pages.myprofile")); ?>"> <i class="bi bi-person-circle"> </i>My
          Account</a>
      </li>
    </ul>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\testarg\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>