

<?php $__env->startSection('content'); ?>
<div class="row text-center">
   <h5>
      You have successfully logged in but as an initializing account.
   </h5> <br />
   <p>Kindly log in as an administrator to continue</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.unauthorizedtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/common/setupadmin.blade.php ENDPATH**/ ?>