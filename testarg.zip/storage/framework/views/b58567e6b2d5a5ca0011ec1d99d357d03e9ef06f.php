<!-- Header-->
<header id="header" class="header">


  <div class="top-right">



    <div class="header-menu">
      <div class="navbar-brand" style="text-align:center">
        <img src="images/home_dsh.jpeg" alt="Logo" style="width:48px;height:32px;">

      </div> <label style="margin-top: 0.4%; margin-right: 40%; font-weight: 900; font-size: 24px;">Research Grants
        Portal</label>
      <?php if(auth()->guard()->guest()): ?>
      <a class="nav-link " href="<?php echo e(route('login')); ?>">Login</a>

      <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>

    <?php endif; ?>

<?php if(auth()->guard()->check()): ?>
<a class="nav-link" href="<?php echo e(route('pages.dashboard')); ?>">Dashboard</a>

<?php endif; ?>
    </div>
  </div>
</header><?php /**PATH C:\xampp\htdocs\testarg\resources\views/partials/headercommon.blade.php ENDPATH**/ ?>