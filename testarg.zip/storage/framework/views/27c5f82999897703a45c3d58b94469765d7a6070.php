<nav class="navbar  navbar-expand-lg navbar-light "
  style="background-color:#88CDFF; padding-top:0px; padding-bottom:0px;">
  <div class="container-fluid">
    <?php if(auth()->guard()->check()): ?>
    <button class="btn btn-primary d-md-none me-2" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
      <i class="bi bi-list"></i>
    </button>
  <?php endif; ?>
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
      <span class="d-none d-lg-inline text-light">University of Kabianga</span>
    </a>
    <div class="mx-auto text-center">
      <h5 class="navbar-text text-light" style="padding:0px;margin:0px;">Uok Call for Annual Grants</h5>
    </div> 
    <?php if(auth()->guard()->check()): ?>
    <a class="btn btn-outline-light ms-auto d-flex align-items-center" href="<?php echo e(route('route.logout')); ?>">
      <i class="bi bi-box-arrow-right me-1"></i>Logout
    </a>
  <?php endif; ?>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\testarg\resources\views/partials/header.blade.php ENDPATH**/ ?>