<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="ARG Portal">
  <meta name="author" content="Tagile Solutions">
  <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
  <title>U.O.K ARG Portal</title>
  
  <?php echo $__env->make('partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
  <?php echo $__env->make('partials.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="wrapper ">
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
     <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="content-wrapper">
        <div class="main">
          <main class="content">
            <?php echo $__env->yieldContent('content'); ?>
          </main>
        </div>
      </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>


  <script>
    $(document).ready(function () { 
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const closeSidebar = document.getElementById('closeSidebar');
        const navbar = document.querySelector('.navbar');
        const overlay = document.getElementById('overlay');

        function toggleSidebar() {
          sidebar.classList.toggle('sidebar-active');
          overlay.classList.toggle('overlay-active');
          if (window.innerWidth <= 767.98) {
            navbar.classList.toggle('navbar-hidden');
          }
        }

        sidebarToggle.addEventListener('click', () => {
          console.log('Sidebar toggle clicked');
          toggleSidebar();
        });

        closeSidebar.addEventListener('click', () => {
          console.log('Close button clicked');
          toggleSidebar();
        });

        overlay.addEventListener('click', () => {
          console.log('Overlay clicked');
          toggleSidebar();
        }); 
    });
  </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\testarg\resources\views/layouts/master.blade.php ENDPATH**/ ?>