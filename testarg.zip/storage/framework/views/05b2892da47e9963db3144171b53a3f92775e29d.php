

<?php $__env->startSection('content'); ?>
<div class="row">


    <?php if(auth()->guard()->check()): ?>
        <style>
            .prop-tabcontainer {
                background-color: #FAF9F6;
                border-radius: 4px;
            }

            .prop-tabpanel {
                border-width: 1px;
                border-color: gray;
                background-color: #FAF9F6;
                border-style: solid;
                border-radius: 4px;
                padding: 8px;
            }

            .form-group {
                margin-bottom: 6px;
            }
        </style>

        <div class="prop-tabcontainer">
            <!-- Nav tabs -->
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link active" id="nav-basicdetails-tab" data-bs-toggle="tab"
                        data-bs-target="#panel-basicdetails" type="button" role="tab" aria-controls="panel-basicdetails"
                        aria-selected="true">Basic Details</button>
                    <button class="nav-link" id="nav-actions-tab" data-bs-toggle="tab" data-bs-target="#panel-actions"
                        type="button" role="tab" aria-controls="panel-actions" aria-selected="false">Actions</button>
                    <button class="nav-link" id="nav-rights-tab" data-bs-toggle="tab" data-bs-target="#panel-rights"
                        type="button" role="tab" aria-controls="panel-rights" aria-selected="false">Rights</button>



                </div>
            </nav>

            <!-- Tab panes -->
            <div class="tab-content prop-tabpanel">

                <!-- basic details Details -->
                <div role="tabpanel" class="tab-pane active" id="panel-basicdetails">
                    <!-- basic Details Form -->
                    <form method="POST" id="basicdetails" enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">Full Name</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="fullname" name="fullname" placeholder="Your Full Name"
                                    value="<?php echo e($user->name); ?>" class="form-control" readonly>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">Email</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="email" name="email" placeholder="Your Email"
                                    value="<?php echo e($user->email); ?>" class="form-control" readonly>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">PF Number</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="pfno" name="pfno" placeholder="Your PF Number"
                                    value="<?php echo e($user->pfno); ?>" class="form-control" readonly>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">Phone Number</label>

                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" id="phonenumber" name="phonenumber" placeholder="Your Phone Number"
                                    value="<?php echo e($user->phonenumber); ?>" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">Registration Date</label>

                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" placeholder="User Registration Date" value="<?php echo e($user->created_at); ?>"
                                    class="form-control" readonly>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">User Role</label>

                            </div>
                            <div class="col-12 col-md-9">
                                <input type="text" placeholder="Your Registration Date"
                                    value="<?php echo e(($user->role == 1) ? 'Admin' : 'Applicant'); ?>" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col text-center">
                                <button id="btn_editprofile" type="button" class="btn btn-info">Edit Profile</button>

                                <button id="btn_updateprofile" class="btn btn-success" disabled hidden>Update</button>
                            </div>
                        </div>

                    </form>

                    <script>
                        $(document).ready(function () {

                            let proposalId = "<?php echo e(isset($prop) ? $prop->proposalid : ''); ?>"; // Check if proposalId is set
                            // Assuming prop is passed to the Blade view from the Laravel controller
                            const collaboratorsurl = `<?php echo e(route('api.proposals.fetchcollaborators', ['id' => ':id'])); ?>`.replace(':id', proposalId);
                            const punlicationsurl = `<?php echo e(route('api.proposals.fetchpublications', ['id' => ':id'])); ?>`.replace(':id', proposalId);
                            document.getElementById('btn_editprofile').addEventListener('click', function () {

                                document.getElementById('fullname').removeAttribute('readonly');
                                document.getElementById('email').removeAttribute('readonly');
                                document.getElementById('phonenumber').removeAttribute('readonly');
                                document.getElementById('pfno').removeAttribute('readonly');
                                document.getElementById('btn_updateprofile').removeAttribute('hidden');
                                document.getElementById('btn_updateprofile').removeAttribute('disabled');
                                this.disabled = true;
                                this.hidden = true;
                            });
                            document.getElementById('btn_updateprofile').addEventListener('click', function () {

                                var formData = $('#form_collaborators').serialize();
                                if (proposalId) {
                                    formData += '&proposalidfk=' + proposalId;
                                }
                                // Function to fetch data using AJAX
                                $.ajax({
                                    url: "<?php echo e(route('api.collaborators.post')); ?>",
                                    type: 'POST',
                                    data: formData,
                                    dataType: 'json',
                                    success: function (response) {
                                        showtoastmessage(response);
                                        // Close the modal
                                        var button = document.getElementById('closecollaboratormodal_button');
                                        if (button) {
                                            button.click();
                                        }
                                        fetchcollaborators();
                                    },
                                    error: function (xhr, status, error) {
                                        var mess = JSON.stringify(xhr.responseJSON.message);
                                        var type = JSON.stringify(xhr.responseJSON.type);
                                        var result = {
                                            message: mess,
                                            type: type
                                        };
                                        showtoastmessage(result);

                                        console.error('Error fetching data:', error);
                                    }
                                });
                            });
                        });
                    </script>
                </div>


                <!-- Actions tab -->
                <div role="tabpanel" class="tab-pane" id="panel-actions">
                    <form method="POST" id="changepasswordform" enctype="multipart/form-data" class="form-horizontal">
                        <?php echo csrf_field(); ?>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">New Password</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="password" id="newpass" name="newpass" placeholder="New Password"
                                    class="form-control">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label">Confirm Password</label>
                            </div>
                            <div class="col-12 col-md-9">
                                <input type="password" id="confirmpass" name="confirmpass" placeholder="Confirm Password"
                                    class="form-control">
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col col-md-3">
                                <label class="form-control-label"></label>
                            </div>
                            <div class="col-12 col-md-9">
                                <div class=" form-check">
                                    <input class="form-check-input" type="checkbox">
                                    <label class="form-check-label" for="flexCheckDefault">By changing this password you confirm that the owner has a CONSENT!</label>
                                    <br />

                                </div>
                            </div>
                            <div class="text-center">
                                <button id="btn_changepassword" type="button" class="btn btn-info">Change Password</button>
                            </div>
                        </div>

                    </form>
                    
                    <hr>
                    <div class="row form-group">
                    <form id="form_userrole" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class=" form-group col-12">
                            <div class=" form-check">
                                <input id="isadmin" name="isadmin" class="form-check-input" type="checkbox" <?php echo e(($user->isadmin) ? 'checked' : ''); ?>>
                                <label for="isadmin" class="form-check-label">This User is Super Admin</i>)</label>
                            </div>
                        </div>
                        <div class="row form-group ">
                        <div class="col-3">
                        <label>Change User Role</label>
                        </div> 
                        <div class="col-9">

                            <select id="userrole" name="userrole" class="form-control">
                            <option value="">Select Status</option>
                            <option value="1" <?php echo e((isset($user) && $user->role == "1") ? 'selected' : ''); ?>>Admin</option>
                            <option value="2" <?php echo e((isset($user) && $user->role == "2") ? 'selected' : ''); ?>>Applicant</option>
                            
                            </select>
                        </div>
                        </div>
                        <div class="col-12 col-md-9">
                            <div class=" form-check">
                                <input id="userisactive" name="userisactive" class="form-check-input" type="checkbox" <?php echo e(($user->isactive) ? 'checked' : ''); ?>>
                                <label for="userisactive" class="form-check-label">User is Active (<i>Can login!</i>)</label>

                                <br />

                            </div>
                        </div>
                        <div class="text-center">
                            <button id="btn_updaterole" type="button" class="btn btn-info">Update User Role</button>
                        </div>
                    </form>
                    </div>
                    <script>
                            $(document).ready(function () {
                                var roleselector= document.getElementById('userrole');
                                var isadmincheckbox = document.getElementById('isadmin');
                                isadmincheckbox.addEventListener('change',function(){
                                if(roleselector){
                                    if (isadmincheckbox.checked) {
                                        roleselector.disabled=true; 
                                        isadmincheckbox
                                    }
                                    else{
                                        roleselector.disabled=false; 
                                    }
                                }
                                });

                                let userid = "<?php echo e(isset($user) ? $user->userid : ''); ?>"; // Check if user is set
                                const passwordchangeurl = `<?php echo e(route('api.users.resetpassword', ['id' => ':id'])); ?>`.replace(':id', userid.toString());
                                const updateroleurl = `<?php echo e(route('api.users.updaterole', ['id' => ':id'])); ?>`.replace(':id', userid.toString());

                                document.getElementById('btn_changepassword').addEventListener('click', function () {

                                    var formData = $('#changepasswordform').serialize();
                                     
                                    // Function to fetch data using AJAX
                                    $.ajax({
                                        url: passwordchangeurl,
                                        type: 'POST',
                                        data: formData,
                                        dataType: 'json',
                                        success: function (response) { 
                                            showtoastmessage(response); 
                                        },
                                        error: function (xhr, status, error) {
                                            var mess = JSON.stringify(xhr.responseJSON.message);
                                            var type = JSON.stringify(xhr.responseJSON.type);
                                            var result = {
                                                message: mess,
                                                type: type
                                            };
                                            showtoastmessage(result);

                                            console.error('Error fetching data:', error);
                                        }
                                    });
                                }); 
                                document.getElementById('btn_updaterole').addEventListener('click', function () {

var formData = $('#form_userrole').serialize();
 
// Function to fetch data using AJAX
$.ajax({
    url: updateroleurl,
    type: 'POST',
    data: formData,
    dataType: 'json',
    success: function (response) { 
        showtoastmessage(response); 
    },
    error: function (xhr, status, error) {
        var mess = JSON.stringify(xhr.responseJSON.message);
        var type = JSON.stringify(xhr.responseJSON.type);
        var result = {
            message: mess,
            type: type
        };
        showtoastmessage(result);

        console.error('Error fetching data:', error);
    }
});
}); 

                            });
                        </script>
                </div>


                <!-- Rights tab -->
                <div role="tabpanel" class="tab-pane" id="panel-rights">
                    <div>
                        <h5 class="text-center">Select permissions preffered for this user only!</h5>
                        <?php if(!(isset($user) && $user->issuperadmin())): ?>
                            <div id="permissions_list_div" class="container mt-1">
                                <div class="card">
                                    <div class="card-header">
                                        Admin Rights
                                    </div>
                                    <div class="card-body">
                                        <?php if(isset($permissions)): ?>
                                        <table class="table table-responsive table-bordered table-hover">
                                        <thead class="bg-secondary text-white">
                                            <td>Value</td>
                                            <td>Menu Name</td>
                                            <td>Role</td>
                                            <td>Description</td>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $permissions->where('targetrole', 1)->toQuery()->orderBy('permissionlevel')->orderBy('priorityno')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr> 
                                                    <td>
                                                        <input id="<?php echo e($perm->pid); ?>" class="form-check-input" value="<?php echo e($perm->pid); ?>"
                                                            type="checkbox" <?php echo e(isset($user) && $user->haspermission($perm->shortname) ? 'checked' : ''); ?>>
                                                    </td>
                                                    <td>
                                                        <label for="<?php echo e($perm->pid); ?>"
                                                            class="form-check-label"><?php echo e($perm->menuname); ?></label>
                                                    </td>
                                                    <td>
                                                        <label for="<?php echo e($perm->pid); ?>"
                                                            class="form-check-label"><?php echo e($perm->targetrole==1? 'Admin' : 'Non Admin'); ?></label>
                                                    </td> 
                                                    <td>
                                                        <label for="<?php echo e($perm->pid); ?>"
                                                            class="form-check-label"><?php echo e($perm->description); ?></label>
                                                    </td> 
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row col-12 form-group">
                                    
                                </div>
                                <div class="card">
                                    <div class="card-header">
                                        Non Admin Rights
                                    </div>
                                    <div class="card-body">
                                        <?php if(isset($permissions)): ?>
                                            <?php $__currentLoopData = $permissions->where('targetrole', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check ">
                                                    <input id="<?php echo e($perm->pid); ?>" class="form-check-input" value="<?php echo e($perm->pid); ?>"
                                                        type="checkbox" <?php echo e(isset($user) && $user->haspermission($perm->shortname) ? 'checked' : ''); ?>>
                                                    <label for="<?php echo e($perm->pid); ?>"
                                                        class="form-check-label"><?php echo e($perm->menuname); ?>---<?php echo e($perm->description); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mt-1">
                                    <div class="col text-center">
                                        <button id="btn_save_permissions" type="button" class="btn btn-primary">Save
                                            Permissions</button>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-center">
                                <h5>This is a superuser (Admin) and reserves all rights exclusively!</h5>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php
                        // Ensure $user is properly encoded to JSON
                        $userJson = json_encode($user);
                    ?>
                    <script>
                        $(document).ready(function () {
                            var user = <?php echo $userJson; ?>;
                            var updateUrlTemplate = "<?php echo e(route('api.users.updatepermissions', ['id' => $user->userid])); ?>";

                            document.getElementById('btn_save_permissions').addEventListener('click', function () {
                                var checkedCheckboxes = document.getElementById('permissions_list_div').querySelectorAll('div input[type="checkbox"]:checked');
                                checkedCheckboxes = Array.from(checkedCheckboxes);
                                var permissions = Array.from(checkedCheckboxes).map(function (checkbox) {
                                    return checkbox.id;
                                });
                                var perm = { 'permissions': permissions }
                                if (perm.permissions.length <= 0) {
                                    showtoastmessage({ 'message': "You must select atleast one Permission!", 'type': "warning" });
                                    return;
                                }
                                var csrfToken = document.getElementsByName('_token')[0].value;
                                perm['_token'] = csrfToken;
                                $.ajax({
                                    url: updateUrlTemplate,
                                    type: 'POST',
                                    dataType: 'json',
                                    data: perm,
                                    success: function (response) {
                                        showtoastmessage(response);
                                    },
                                    error: function (xhr, status, error) {
                                        showtoastmessage({ 'message': 'Error Occured!', 'type': 'danger' })
                                        console.error('Error fetching data:', error);
                                    }
                                });

                            });
                            // Function to fetch data using AJAX
                            function fetchData() {
                                $.ajax({
                                    url: "<?php echo e(route('api.users.fetchallusers')); ?>",
                                    type: 'GET',
                                    dataType: 'json',
                                    success: function (response) {
                                        populateTable(response);
                                    },
                                    error: function (xhr, status, error) {
                                        console.error('Error fetching data:', error);
                                    }
                                });
                            }

                            // Function to search data using AJAX
                            function searchData(searchTerm) {
                                $.ajax({
                                    url: "<?php echo e(route('api.users.fetchsearchusers')); ?>",
                                    type: 'GET',
                                    dataType: 'json',
                                    data: {
                                        search: searchTerm
                                    },
                                    success: function (response) {

                                        populateTable(response);
                                    },
                                    error: function (xhr, status, error) {
                                        console.error('Error searching data:', error);
                                    }
                                });
                            }
                            var routeUrlTemplate = "<?php echo e(route('pages.users.viewsingleuser', ['id' => '__ID__'])); ?>";

                            // Function to populate table with data
                            function populateTable(data) {
                                var tbody = $('#proposalstable tbody');
                                tbody.empty(); // Clear existing table rows
                                if (data.length > 0) {
                                    $.each(data, function (index, data) {
                                        var userurl = routeUrlTemplate.replace('__ID__', data.userid);
                                        var row = '<tr>' +
                                            '<td>' + data.name + '</td>' +
                                            '<td><a class="nav-link pt-0 pb-0" href="' + userurl + '">' + data.email + '</a></td>' +
                                            '<td>' + data.pfno + '</td>' +
                                            '<td>' + Boolean(data.isactive) + '</td>' +
                                            '<td>' + new Date(data.created_at).toDateString("en-US") + '</td>' +
                                            '</tr>';
                                        tbody.append(row);
                                    });
                                }
                                else {
                                    var row = '<tr><td colspan="5">No Users found</td></tr>';
                                    tbody.append(row);
                                }
                            }

                            function showtoastmessage(response) {

                                var toastEl = document.getElementById('liveToast');
                                if (toastEl) {
                                    var toastbody = document.getElementById('toastmessage_body');
                                    var toastheader = document.getElementById('toastheader');
                                    toastheader.classList.remove('bg-primary', 'bg-success', 'bg-danger', 'bg-info', 'bg-warning', 'bg-secondary');

                                    if (response && response.type) {
                                        if (response.type == "success") {
                                            toastheader.classList.add('bg-success');
                                        }
                                        else if (response.type == "warning") {
                                            toastheader.classList.add('bg-warning');
                                        }
                                        else {
                                            toastheader.classList.add('bg-danger');
                                        }
                                    }
                                    else {
                                        toastheader.classList.add('bg-danger');
                                    }
                                    toastbody.innerText = response && response.message ? response.message : "No Message";
                                    var toast = new bootstrap.Toast(toastEl, {
                                        autohide: true,
                                        delay: 2000
                                    });
                                    toast.show();
                                }
                            }

                            // Initial fetch when the page loads
                            fetchData();

                            // Search input keyup event
                            $('#searchInput').on('keyup', function () {
                                var searchTerm = $(this).val().toLowerCase();
                                if (searchTerm.length >= 3) { // Optional: adjust the minimum search term length
                                    searchData(searchTerm);
                                } else if (searchTerm.length === 0) {
                                    fetchData(); // Fetch all data when search input is empty
                                }
                            });
                        });
                    </script>
                </div>


            </div>
        </div>
    <?php endif; ?>
</div>
<script>
    $(document).ready(function () {
        

        // Function to fetch data using AJAX
        function fetchData() {
            $.ajax({
                url: "<?php echo e(route('api.users.fetchallusers')); ?>",
                type: 'GET',
                dataType: 'json',
                success: function (response) {
                    populateTable(response);
                },
                error: function (xhr, status, error) {
                    console.error('Error fetching data:', error);
                }
            });
        }

        // Function to search data using AJAX
        function searchData(searchTerm) {
            $.ajax({
                url: "<?php echo e(route('api.users.fetchsearchusers')); ?>",
                type: 'GET',
                dataType: 'json',
                data: {
                    search: searchTerm
                },
                success: function (response) {

                    populateTable(response);
                },
                error: function (xhr, status, error) {
                    console.error('Error searching data:', error);
                }
            });
        }
        var routeUrlTemplate = "<?php echo e(route('pages.users.viewsingleuser', ['id' => '__ID__'])); ?>";

        // Function to populate table with data
        function populateTable(data) {
            var tbody = $('#proposalstable tbody');
            tbody.empty(); // Clear existing table rows
            if (data.length > 0) {
                $.each(data, function (index, data) {
                    var userurl = routeUrlTemplate.replace('__ID__', data.userid);
                    var row = '<tr>' +
                        '<td>' + data.name + '</td>' +
                        '<td><a class="nav-link pt-0 pb-0" href="' + userurl + '">' + data.email + '</a></td>' +
                        '<td>' + data.pfno + '</td>' +
                        '<td>' + Boolean(data.isactive) + '</td>' +
                        '<td>' + new Date(data.created_at).toDateString("en-US") + '</td>' +
                        '</tr>';
                    tbody.append(row);
                });
            }
            else {
                var row = '<tr><td colspan="5">No Users found</td></tr>';
                tbody.append(row);
            }
        }

        // Initial fetch when the page loads
        fetchData();

        // Search input keyup event
        $('#searchInput').on('keyup', function () {
            var searchTerm = $(this).val().toLowerCase();
            if (searchTerm.length >= 3) { // Optional: adjust the minimum search term length
                searchData(searchTerm);
            } else if (searchTerm.length === 0) {
                fetchData(); // Fetch all data when search input is empty
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/users/viewuser.blade.php ENDPATH**/ ?>