

<?php $__env->startSection('content'); ?>
   <div class="jumbotron text-center">
      <h3>U.O.K Call for Papers </h3>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.unauthorizedtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testarg\resources\views/pages/common/home.blade.php ENDPATH**/ ?>