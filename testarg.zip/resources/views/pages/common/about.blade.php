@extends('layouts.master')

@section('content')
   This is about page
@endsection